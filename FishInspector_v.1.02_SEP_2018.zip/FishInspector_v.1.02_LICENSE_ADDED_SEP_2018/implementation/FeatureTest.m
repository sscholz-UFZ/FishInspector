function FeatureTest
    addpath 'C:\Users\tobi\Documents\Freelancer\UFZ\implementation\tks3_tools'
    
    base = 'C:\Users\tobi\Documents\Freelancer\Julien Philippe\data\jaw 5X';
%     base = 'C:\Users\tobi\Documents\Freelancer\Julien Philippe\data\jaw 10X';
%     base = 'C:\Users\tobi\Documents\Freelancer\Julien Philippe\data\Phenotypes to screen\AcTub\Affected 3dpf';
%     base = 'C:\Users\tobi\Documents\Freelancer\Julien Philippe\data\Phenotypes to screen\AcTub\Control 3dpf';
%     base = 'C:\Users\tobi\Documents\Freelancer\Julien Philippe\data\Phenotypes to screen\Fli1\eye vasculature\affected';
%    base = 'C:\Users\tobi\Documents\Freelancer\UFZ\data\360\Well_A02';
    base = 'C:\Users\tobi\Documents\Freelancer\UFZ\data\160526_Zebrafish images_high resolution\96 hpf';% rescaled';
    base = 'C:\Users\tobi\Documents\Freelancer\Julien Philippe\data\Phenotypes to screen\TUNEL\Ctrl';
    base = 'C:\Users\tobi\Documents\Freelancer\Julien Philippe\data\jaw 10X';
    base = 'C:\Users\tobi\Documents\Freelancer\Julien Philippe\data\Phenotypes to screen\Kidney1\affected';
    base = 'C:\Users\tobi\Documents\Freelancer\Julien Philippe\data\Phenotypes to screen\GnRH\affected';
    base = 'C:\Users\tobi\Documents\Freelancer\Julien Philippe\data\Phenotypes to screen\Fli1\trunk vasculature\control';
    allFiles = dir(fullfile(base));
    [~, ~, ext] = arrayfun(@(x) fileparts(x.name), allFiles, 'Uniform', 0);
    imfmts = imformats; imfmts = [imfmts.ext]; imfmts = cellfun(@(x) ['.', x], imfmts, 'Uniform', 0);
    allFiles(arrayfun(@(x, x2) x.isdir || ismember(x.name, {'.', '..'}) || ~ismember(x2, imfmts), allFiles, ext)) = [];
    allFiles = {allFiles.name};
    imref = [];
    thisImage = [];
    
    
    pc = parameterPanelClass;
            % ===========    TAG                 NAME                                   TYPE        DEFAULT     MIN     MAX                 INCREMENT   HasAuto  
    pc.addParameterControl( 'MetricThreshold',  'Strongest feature threshold',          'numeric',  1000,       0,      inf,                100,        false)
    pc.addParameterControl( 'NumOctaves',       'Number of octaves',                    'numeric',  3,          1,      inf,                1,          false)
    pc.addParameterControl( 'NumScaleLevels',   'Number of scale levels per octave',    'numeric',  4,          3,      inf,                1,          false)
    pc.addParameterControl( 'numStrongPoints',  'Plot X strongest Points',              'numeric',  10,         1,      inf,                1,          false)
    pc.addParameterControl( 'refFileNum',       'File Number (Reference)',              'numeric',  1,          1,      length(allFiles),   1,          false)
    pc.addParameterControl( 'fileNum',          'File Number',                          'numeric',  1,          1,      length(allFiles),   1,          false)
    pc.manualModeEnable          = false;
    pc.UpdateCalculationFunction = @UpdateCalculationFunction;
    pc.DrawingFunction           = @DrawingFunction;
    pc.makeFigure;

    function im1 = readImageFile(fileNumber)
        im1 = double(imread(fullfile(base, allFiles{fileNumber})));
        im1 = im1-min(im1(:)); im1 = im1./max(im1(:));
        if length(size(im1))>2
            im1 = rgb2gray(im1);
        end
        %im1 = imfilter(im1, fspecial('average', 15));
        %im1 = im2bw(im1, graythresh(im1));
    end
    
    function out = UpdateCalculationFunction(parameter, varargin)
        disp('calculating');
    
        fn = fieldnames(parameter); fn = fn(1:3);
        args = [fn(:), cellfun(@(x) parameter.(x), fn, 'Uniform', 0)]';
        disp({args{:}});

        featureFunction = @(varargin) detectSURFFeatures(varargin{:});
        
        imref = readImageFile(parameter.refFileNum);
        pointsRef = featureFunction(imref, args{:});
        [featuresRef, valid_pointsRef] = extractFeatures(imref, pointsRef);

        thisImage = readImageFile(parameter.fileNum);
        pointsThisImage = featureFunction(thisImage, args{:});
        [featuresThisImage, valid_pointsThisImage] = extractFeatures(thisImage, pointsThisImage);

        indexPairs = matchFeatures(featuresRef, featuresThisImage);

        matchedPoints1 = valid_pointsRef(indexPairs(:,1),:);
        matchedPoints2 = valid_pointsThisImage(indexPairs(:,2),:);
        
        out = struct('pointsThisImage', pointsThisImage,...
                     'matchedPoints1', matchedPoints1,...
                     'matchedPoints2', matchedPoints2);
    end

    function DrawingFunction(hax, data, parameter, varargin)
        cla(hax.axes1);
%         imshow(im1_orig, 'parent', hax.axes1)
%         hold(hax.axes1, 'on')
%             plot(data.points.selectStrongest(parameter.numStrongPoints), hax.axes1)
%         hold(hax.axes1, 'off')
        showMatchedFeatures(imref,thisImage,data.matchedPoints1,data.matchedPoints2);
    end    
    
    


end